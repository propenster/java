
public class Account{

private int account;
private String firstName;
private String lastName;
private double balance;
//no-arg constructor
public Account(){
this(0,"","",0);
}
//call four no-arg construc
// initaialis a record
public Account(int acct, String first, String last, double bal){
account = acct;
firstName = firstName;
lastName = last;
balance = bal;
}
//setter method for account
public void setAccount(int acct){
account = acct;
}
//getter method for account
public int getAccount(){
return account;
}
//
public void setFirstName(String first){
firstName = first;
}
//
public String getFirstName(){
return firstName;
}
//
public void setLastName(String last){
lastName = last;
}
//
public String getLastName(){
return lastName;
}
//set balance
public void setBalance(double bal){
balance = bal;
}
//
public double getBalance(){
return balance;
}
public String toString(){
return String.format("%d\t%s\t%s\t%.2f",getAccount(),getFirstName(),getLastName(),getBalance());
}
//

public static void main(String[]args){
Account ac = new Account(200,"Faith","Olusegun",3890.67);
ac.toString();
}

}
