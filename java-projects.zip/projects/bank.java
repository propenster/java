
public class bank{

private int bank;
private String firstName;
private String lastName;
private double balance;
//no-arg constructor
public bank(){
this(0,"","",0);
}
//call four no-arg construc
// initaialis a record
public bank(int acct, String first, String last, double bal){
bank = acct;
firstName = firstName;
lastName = last;
balance = bal;
}
//setter method for bank
public void setbank(int acct){
bank = acct;
}
//getter method for bank
public int getbank(){
return bank;
}
//
public void setFirstName(String first){
firstName = first;
}
//
public String getFirstName(){
return firstName;
}
//
public void setLastName(String last){
lastName = last;
}
//
public String getLastName(){
return lastName;
}
//set balance
public void setBalance(double bal){
balance = bal;
}
//
public double getBalance(){
return balance;
}
public String toString(){
return String.format("%d\t%s\t%s\t%.2f",getbank(),getFirstName(),getLastName(),getBalance());
}
//

public static void main(String[]args){
bank ac = new bank(200,"Faith","Olusegun",3890.67);
ac.toString();
}

}
