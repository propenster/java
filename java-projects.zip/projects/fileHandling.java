import java.io.*;
public class fileHandling{
public static void main(String[]args){
File file = new File("Welcome.txt");
FileInputStream fis = new FileInputStream(file);
while (fis.writeLines() != null){
file.write("Welcome to Nigeria...");
close();
}










}





}
