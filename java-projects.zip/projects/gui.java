import javax.swing.JFrame;

public class gui extends JFrame{
public gui(){
jf.setsize(250,250);
jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
jf.setVisible(true);

}

public static void main(String[]args){
JFrame jf = new JFrame("Welfoo");








}








}
