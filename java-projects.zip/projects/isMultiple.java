import java.util.Scanner;
public class isMultiple{
public static void main(String[]args){
Scanner input = new Scanner(System.in);
System.out.println("Enter the first number: ");
int firstNum = input.nextInt();
System.out.println("Enter the second number: ");
int secondNum = input.nextInt();
if (secondNum % firstNum == 0){
System.out.println(firstNum+" is a multiple of "+secondNum);
}
else{
System.out.println(firstNum+" is not a multiple of "+secondNum);
}
System.out.println();





}


}
