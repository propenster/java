/*******************************************************/
/* Developed By : Jake Rodriguez Pomperada, MAED-IT */
/* Mobile : 09296768375 */
/* E-mail : jakerpomperada@yahoo.com */
/*******************************************************/



import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
class Frame1 extends JFrame implements ActionListener
{

       
       JLabel lbl=new JLabel("Employee Payroll System Version 1.0");

       Font f=new Font("Times",Font.BOLD,24);
       Font f1=new Font("Times",Font.BOLD,14);
       
       JLabel lblid,lblname,lblcity,lblsex,lblsal,lblsubmit;
       JTextField txtid,txtname,txtcity,txtsal;
       JRadioButton rbmale,rbfemale;
       JButton btnadd,btnsave,btnupdate,btndelete,btnexit;
       JButton btnnext,btnprev,btnlast,btnfirst;
       String gen;
       ResultSet rs=null;
       Connection con=null;
       Statement stmt=null;
       
       Frame1()
       {
       // this is display in a Frame titlebar.
       super("Employees Information Details");
       addWindowListener(new WindowAdapter(){
                public void windowClosing(WindowEvent we)
                {
                System.exit(0);
                }
       });
       // set layout to null
       setLayout(null);

       lblsubmit=new JLabel("Developed By : Jake Rodriguez Pomperada, MAED-IT");
       add(lblsubmit);
       lblsubmit.setBounds(420,540,350,20);

       // add lbl label on form.
       add(lbl);

       // set the particular position on a screen
       lbl.setBounds(200,50,500,30);

       // set the font of lbl label 
       lbl.setFont(f);
      

       // initializa all the label which are declared in the example above with its caption name 
       lblid=new JLabel("ID");
       lblname=new JLabel("NAME");
       lblcity=new JLabel("CITY");
       lblsal=new JLabel("SALARY");
       lblsex=new JLabel("SEX");
       lblid.setBounds(300,140,100,20);
       lblname.setBounds(300,180,100,20);
       lblcity.setBounds(300,220,100,20);
       lblsal.setBounds(300,260,100,20);
       lblsex.setBounds(300,300,100,20);

       // add all the label on the frame
       add(lblid);
       add(lblname);
       add(lblcity);
       add(lblsal);
       add(lblsex);

       // set font
       lblid.setFont(f1);
       lblname.setFont(f1);
       lblcity.setFont(f1);
       lblsal.setFont(f1);
       lblsex.setFont(f1);


       // initialize the textfield with size
       txtid=new JTextField(15);
       txtname=new JTextField(15);
       txtcity=new JTextField(15);
       txtsal=new JTextField(15);
       rbmale=new JRadioButton("Male");
       rbfemale=new JRadioButton("Female");

       // set a particlar position on a screen with setbounds constructor
       txtid.setBounds(400,140,100,20);
       txtname.setBounds(400,180,100,20);
       txtcity.setBounds(400,220,100,20);
       txtsal.setBounds(400,260,100,20);
       rbmale.setBounds(400,300,70,20);
       rbfemale.setBounds(470,300,70,20);


       // add textfield on a Frame
       add(txtid);
       add(txtname);
       add(txtcity);
       add(txtsal);
       add(rbmale);
      add(rbfemale);


      // create a button group for radio button
       ButtonGroup bg=new ButtonGroup();

       // add button to group
       bg.add(rbmale);
       bg.add(rbfemale);


       // register radio button
       rbmale.addActionListener(this);
       rbfemale.addActionListener(this);

       // initializa button with its caption
       btnadd=new JButton("Add");
       btnsave=new JButton("Save");
       btnupdate=new JButton("Update");
       btndelete=new JButton("Delete");

       // set a particular position on a Frame
       btnadd.setBounds(200,400,100,30);
       btnsave.setBounds(310,400,100,30);
       btnupdate.setBounds(420,400,100,30);
       btndelete.setBounds(530,400,100,30);

       // add button on a frame
       add(btnadd);
       add(btnsave);
       add(btndelete);
       add(btnupdate);

       // register all the button
       btnadd.addActionListener(this);
       btnsave.addActionListener(this);
       btnupdate.addActionListener(this);
       btndelete.addActionListener(this);
       

       // initializa nevigation button with its caption
       btnfirst=new JButton("First");
       btnnext=new JButton("Next");
       btnprev=new JButton("Previous");
       btnlast=new JButton("Last");

       // set a particular position on a  screen with setbounds constructor
       btnfirst.setBounds(200,440,100,30);
       btnnext.setBounds(310,440,100,30);
       btnprev.setBounds(420,440,100,30);
       btnlast.setBounds(530,440,100,30);

       // add all the button on frame
       add(btnfirst);
       add(btnnext);
       add(btnprev);
       add(btnlast);

       // register all the button 
       btnfirst.addActionListener(this);
       btnnext.addActionListener(this);
       btnprev.addActionListener(this);
       btnlast.addActionListener(this);
       
       btnexit=new JButton("Exit");
       btnexit.setBounds(360,480,100,30);
       add(btnexit);
       btnexit.addActionListener(this);

       // open database connection
       // here we call a dbopen() method
       dbOpen();
       }

       
       public void actionPerformed(ActionEvent ae)
	{
		try
		{
			
	 		if(ae.getActionCommand()=="Add")
			{
				txtid.setText("");
				txtname.setText("");
				txtcity.setText("");
				txtsal.setText("");
			}
			if(ae.getActionCommand()=="Update")
			{
				stmt.executeUpdate("UPDATE prog11 SET name='" + txtname.getText() + "',city='" + txtcity.getText() + "',sal=" + txtsal.getText() + ",sex='"+gen+"' WHERE id=" + txtid.getText() + "");
				dbClose();
				dbOpen();
			}
			if(ae.getActionCommand()=="Delete")
			{
				stmt.executeUpdate("DELETE FROM prog11 WHERE id=" + txtid.getText() + "");			
				dbClose();
				dbOpen();
			}	
			if(ae.getActionCommand()=="Save")
			{
				stmt.executeUpdate("INSERT INTO prog11 VALUES('" + txtid.getText() + "','" + txtname.getText() + "','" + txtcity.getText() + "'," + txtsal.getText() + ",'"+gen+"')");
				dbClose();
				dbOpen();
			}
			if(ae.getActionCommand()=="Next")
			{
				if(rs.next())
				{
					setText();                 			setText();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "You are At Already Last Record", "Message", JOptionPane.ERROR_MESSAGE);	
                  		}
			}
			if(ae.getActionCommand()=="Previous")
			{
				if(rs.previous())
				{
                  			setText();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "You Are At Already First Record", "Message", JOptionPane.ERROR_MESSAGE);
                  		}
			}
			if (ae.getActionCommand()=="First")
			{
				if(rs.first())
				{
					setText();
				}
			}
			if (ae.getActionCommand()=="Last")
			{
				if(rs.last())
				{
					setText();
				}
			}
			if(ae.getActionCommand()=="Exit")
			{
			System.exit(0);		
			}
			if(ae.getActionCommand()=="Female")
			 {
				gen="Female";
			 }
			 else
			 {
				gen="Male";
			 }
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void dbOpen()
	{
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

                        // here in this statement mydsn is a DSN name which u have to create before run this program
                        // step to create dsn
                        // open control panel-> open administrativr tools-> open data source(ODBC)-> press add
                        //->select microsoft access driver(*.mdb) then finish->give data source name-> select database and press ok
                        // again press ok.
                        con=DriverManager.getConnection("jdbc:odbc:mydsn");
			stmt=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("Select * from prog11");
			if(rs.next())
			setText();
		}catch(Exception e){}
	}
	public void dbClose()
	{
		try{stmt.close();
		rs.close();
		con.close();
		}catch(Exception e){}
	}
	public void setText(){
		try{
			txtid.setText(rs.getString(1));
			txtname.setText(rs.getString(2));
			txtcity.setText(rs.getString(3));
			txtsal.setText(rs.getString(4));
			if(rs.getString(5).equals("Male")) 
			{	
				rbmale.setSelected(true);
			}	
			else
			{
				rbfemale.setSelected(true);
			}
	    	}catch(Exception ex){}		
	    	}
}

public class next_pre
{
        public static void main(String ar[])throws Exception
        {

        // create a object of Frame1 class in main method
        Frame1 f1=new Frame1();

        // set frame size
        f1.setSize(800,600);

        // set frame visible true
        f1.setVisible(true);
        //set look and feel for frame
	UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        }
}
