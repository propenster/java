import java.util.Scanner;
public class numChecker{

public static void main(String[]args){

Scanner input = new Scanner(System.in);
System.out.println("Enter the first number(an integer number preferably): ");
int num1 = input.nextInt();
System.out.println("Enter the second number(an integer number preferably): ");
int num2 = input.nextInt();
if (num1 != num2){
System.out.println(num1+" != "+num2);

}
if (num1 <= num2){
System.out.println(num1+" <= "+num2);
}
if (num1 >= num2){
System.out.println(num1+" >= "+num2);
}
if (num1 > num2){
System.out.println(num1+" > "+num2);
}
if (num1 < num2){
System.out.println(num1+" < "+num2);
}
Sytem.out.println("\n\nThanks for using this program,\nCheck the new version below:..");

// number CHecker version 2.0
System.out.println("Enter the first number(an integer number preferably): ");
int num3 = input.nextInt();
System.out.println("Enter the second number(an integer number preferably): ");
int num4 = input.nextInt();
System.out.println("Enter the third number(an integer number preferably): ");
int num5 = input.nextInt();
public int getSum(){
return num3+num4+num5;
}
System.out.println("Sum of "+num3+" "+num4+" "+num5+" is - "+getSum());
System.out.println("Average of "+num3+" "+num4+" "+num5+" is - "+getSum()/3);
}
}
