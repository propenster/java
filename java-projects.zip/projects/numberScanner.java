import java.util.Scanner;
import java.Math;
public class numberScanner{
public static void main(String[]args){
Scanner input = new Scanner(System.in);
System.out.println("How many numbers will you like to test...");
int numTest = input.nextInt();
for (int i=0; i<numTest; i++){
System.out.println("Enter first number: ");
input.nextInt();
System.out.println("The highest is "+max(input));
}










}















}
