public class pattern{
public static void main(String[]args){

for (int i=0; i<9; i++){
System.out.print("*");
if (i==8){
System.out.print("\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n*\t*\n");
for(int j=0; j<9; j++){
System.out.print("*");
}
System.out.println();
}




}







}





}
