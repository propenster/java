public class phoneStore{
private String name;
private String model;
private String dated;

public phoneStore(String n, String m, String d){
name = n;
model = m;
dated = d;

public void setName(String n){
name = n;
}
public String getName(){
return name;
}
public void setModel(String m){
model = m;
}
public String getModel(){
return model;
}
public void setDate(String d){
dated = d;
}
public String getDate(String d){
return dated;
}

public void descPhone(){
System.out.prinf("Phone: %s\nModel: %s\nDate of Stock: %s\n",getName(),getModel(),getDate()); 
}
public class techno extends phoneStore{
private int price;
public techno(String name, String model, String dated, int p){
super(name, model, dated);
this.price = p;
}
public void descPhone(){
System.out.print("Phone Details"); 
super.descPhone();
}

public static void main(String[]args){
techno t = new techno("P5","Techno","12/5/2098",25);
t.descPhone();
}



}



}





















}
