public class student{
private String name;
private String department;
private static int rollno;

public student(){
this("","");
}
public student(String n, String d){
name = n;
department = d;
rollno++;
}

public void setName(String n){
name = n;
}
public String getName(){
return name;
}
public void setDept(String d){
department = d;
}
public String getDept(){
return department;
}
public void getDetails(){
System.out.printf("Student's Name: %s\nDepartment: %s\nRoll Number: %d\n\n",getName(),getDept(),rollno);
}

public static void main(String[]args){
student faith = new student();
faith.getDetails();
student bl = new student("Olabosoye Blessing P.","Animal Prod. & Health");
bl.getDetails();
student tolu = new student("Balogun Tolulope M.","Animal Prod. & Health");
tolu.getDetails();


}




}
