public class wellcome{
public static void main(String[]args){
System.out.println("You are welcome to JAVA with UBUNTU:");


}





}
